import { describe, expect, it } from "vitest";
import { checkBody, MAX_BODY, ALLOWED_OPS } from "@/lib/gateway";
import { createLimiter } from "@/lib/ratelimit";
const auth = (op: string) => ({ account_id: "a.near", public_key: "ed25519:x", signature: "s", nonce: "n", recipient: "keyhole", message: JSON.stringify({ op, account_id: "a.near", ts_ms: 1, params: {} }) });

describe("gateway body checks", () => {
  it("allows info and the public key log without auth", () => {
    expect(checkBody('{"op":"info"}')).toMatchObject({ ok: true, op: "info" });
    expect(checkBody('{"op":"provenance","token_id":"kabc"}')).toMatchObject({ ok: true, op: "provenance" });
  });
  it("allows the public record without auth, and nothing else new", () => {
    // The listing card sends the key id at the top level; the route forwards it to the enclave as params.token_id.
    expect(checkBody('{"op":"record","token_id":"k5f4750858f328940"}')).toMatchObject({ ok: true, op: "record" });
    expect(ALLOWED_OPS as readonly string[]).toContain("record");
    expect(checkBody('{"op":"record"}')).toMatchObject({ ok: false, code: "bad_params" });
    expect(checkBody('{"op":"record","token_id":"../x"}')).toMatchObject({ ok: false, code: "bad_params" });
  });
  it.each(["copy", "sweep_minter", "", "INFO"])("blocks op %s even with an auth object", (op) => expect(checkBody(JSON.stringify({ op, auth: auth(op || "swap") }))).toMatchObject({ ok: false, code: "bad_op" }));
  it("refuses unsigned or incomplete swap and withdraw", () => {
    for (const op of ["swap", "withdraw"]) {
      expect(checkBody(JSON.stringify({ op }))).toMatchObject({ ok: false, code: "no_auth" });
      expect(checkBody(JSON.stringify({ op, auth: { account_id: "a.near" } }))).toMatchObject({ ok: false, code: "no_auth" });
      expect(checkBody(JSON.stringify({ op, auth: "junk" }))).toMatchObject({ ok: false, code: "no_auth" });
    }
  });
  it("refuses a fund op whose signed message names a different op", () => {
    expect(checkBody(JSON.stringify({ op: "swap", auth: auth("withdraw") }))).toMatchObject({ code: "op_mismatch" });
    expect(checkBody(JSON.stringify({ op: "withdraw", auth: auth("swap") }))).toMatchObject({ code: "op_mismatch" });
  });
  it("relays swap and withdraw only with a complete NEP-413 auth for that op", () => {
    for (const op of ["swap", "withdraw"] as const) expect(checkBody(JSON.stringify({ op, auth: auth(op) }))).toMatchObject({ ok: true, op });
    expect(ALLOWED_OPS).toEqual(expect.arrayContaining(["swap", "withdraw"]));
    expect(ALLOWED_OPS as readonly string[]).not.toContain("copy");
    expect(ALLOWED_OPS as readonly string[]).not.toContain("sweep_minter");
  });
  it("allows the signed record of a key without auth, and only for a key id", () => {
    expect(checkBody('{"op":"record","token_id":"k5f4750858f328940"}')).toEqual({ ok: true, op: "record" });
    expect(checkBody('{"op":"record","token_id":"0"}')).toMatchObject({ ok: true, op: "record" });
    for (const body of ['{"op":"record"}', '{"op":"record","token_id":"../x"}', '{"op":"record","token_id":""}', '{"op":"record","token_id":12}']) {
      expect(checkBody(body), body).toMatchObject({ ok: false, code: "bad_params" });
    }
    expect(ALLOWED_OPS as readonly string[]).toContain("record");
  });
  it("requires all auth fields", () => expect(checkBody('{"op":"status","auth":{"account_id":"a"}}')).toMatchObject({ code: "no_auth" }));
  it("rejects op/message mismatch", () => expect(checkBody(JSON.stringify({ op: "mint", auth: auth("status") }))).toMatchObject({ code: "op_mismatch" }));
  it("rejects bad JSON", () => expect(checkBody("{")).toMatchObject({ code: "bad_params" }));
  it("rejects > 8 KB", () => expect(checkBody("x".repeat(MAX_BODY + 1))).toMatchObject({ status: 413, code: "too_large" }));
  it("accepts a well-formed signed request", () => expect(checkBody(JSON.stringify({ op: "quote", auth: auth("quote") }))).toMatchObject({ ok: true }));
  it("accepts eip191 auth when the signed op matches", () => {
    const message = JSON.stringify({ op: "status", account_id: "0xabc", ts_ms: 1, params: {}, nonce: "n", recipient: "keyhole" });
    const body = { scheme: "eip191", account_id: "0xabc", address: "0xabc", signature: "0x11", nonce: "n", recipient: "keyhole", message };
    expect(checkBody(JSON.stringify({ op: "status", auth: body }))).toMatchObject({ ok: true, op: "status" });
    expect(checkBody(JSON.stringify({ op: "mint", auth: body }))).toMatchObject({ code: "op_mismatch" });
  });
});
describe("rate limiter", () => {
  it("limits per key and resets after the window", () => {
    const l = createLimiter(3, 1000);
    expect([1, 2, 3].map(() => l("ip", 0).ok)).toEqual([true, true, true]);
    expect(l("ip", 10)).toEqual({ ok: false, retryAfter: 1 });
    expect(l("other", 10).ok).toBe(true);
    expect(l("ip", 1001).ok).toBe(true);
  });
});

// RED review R4: the worker's wallet polling must finish before the gateway gives up on the call.
import { readFileSync as rf } from "node:fs";
it("worker wallet polling fits inside the gateway timeout", () => {
  const route = rf(`${__dirname}/../app/api/worker/route.ts`, "utf8");
  const lib = rf(`${__dirname}/../../tee/worker/src/lib.rs`, "utf8");
  const gw = Number(/AbortSignal\.timeout\((\d[\d_]*)\)/.exec(route)![1].replace(/_/g, "")) / 1000;
  const n = Number(/WALLET_POLLS: u32 = (\d+)/.exec(lib)![1]), sec = Number(/WALLET_POLL_SECS: u64 = (\d+)/.exec(lib)![1]);
  expect(Number(/GATEWAY_TIMEOUT_SECS: u64 = (\d+)/.exec(lib)![1])).toBe(gw);
  expect(n * sec + 5).toBeLessThan(gw);
});
