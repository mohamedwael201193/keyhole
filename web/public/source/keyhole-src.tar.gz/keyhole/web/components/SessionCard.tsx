"use client";
import { useEffect, useState } from "react";
import { useWallet } from "@/lib/wallet";
import { minutesLeft } from "@/lib/session";
import { ErrorBox } from "./Result";
import { Spinner } from "./ui";
import { SuccessCheck } from "./motion";

/** Unlock (one wallet signature for 30 minutes) or show the live session with Revoke. */
export function SessionCard({ tokenId }: { tokenId: string }) {
  const { session, startSession, revokeSession, via } = useWallet();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [, tick] = useState(0);
  useEffect(() => { const id = setInterval(() => tick((n) => n + 1), 20_000); return () => clearInterval(id); }, []);
  const live = session && session.token_id === tokenId ? session : null;
  if (live) {
    return (
      <div className="sess on" data-testid="session-on">
        <span><SuccessCheck size={18} /> <b>Unlocked</b> · {minutesLeft(live)} min left · trades up to ${(live.max_usd_micro / 1e6).toFixed(2)} need no more wallet popups. Withdrawals always ask your wallet.</span>
        <button className="btn b2" type="button" data-testid="session-revoke" onClick={() => void revokeSession()}>Lock now</button>
      </div>
    );
  }
  return (
    <div className="sess" data-testid="session-off">
      <span><b>Unlock for 30 minutes.</b> Sign once; the enclave then accepts your reads and trades (up to $5 in total) without another popup. Withdrawals, raising limits, locking and proofs still ask your wallet.</span>
      <button className="btn b1" type="button" data-testid="session-unlock" disabled={busy} onClick={async () => { setBusy(true); setErr(null); const r = await startSession(tokenId); setBusy(false); if (!r.ok) setErr(r.code); }}>
        {busy ? <><Spinner label={via === "privy" ? "Signing securely" : "Waiting for your wallet"} /> {via === "privy" ? "Signing securely…" : "Confirm in your wallet…"}</> : "Unlock (1 signature)"}
      </button>
      {err && <ErrorBox code={err} />}
    </div>
  );
}
