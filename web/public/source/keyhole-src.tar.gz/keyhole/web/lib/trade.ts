import { ASSETS, type AssetKey } from "./assets";
import { chainOfAsset } from "./destination";

/**
 * Request params for the worker, matching the CLI in cli/src/cli.ts.
 *
 * Swap and withdraw send NEP-141 asset ids (`nep141:…`). `usd_of` prices a token
 * only when it equals the USDC asset id or is an origin asset id, then
 * `/wallet/v1/confidential/withdraw` receives that same string.
 *
 * Fund uses the symbol. `op_account` forwards `token` to the deposit API,
 * whose default is the symbol `"USDC"`.
 */
export function swapParams(from: AssetKey, to: AssetKey, amountIn: string, minAmountOut?: string) {
  return swapParamsById(ASSETS[from].id, ASSETS[to].id, amountIn, minAmountOut);
}

/** The swap for any two 1Click asset ids (the swap screen offers the whole token list). Amounts are base units. */
export function swapParamsById(fromId: string, toId: string, amountIn: string, minAmountOut?: string) {
  return {
    token_in: fromId,
    token_out: toId,
    amount_in: amountIn,
    // Only a positive integer is a floor. Zero would be refused by the enclave, so it is left out (the enclave then derives one).
    ...(minAmountOut && /^[1-9]\d*$/.test(minAmountOut) ? { min_amount_out: minAmountOut } : {}),
  };
}

/** The payout: to the signed-in account on the token's own chain by default; `dest` names another address on that chain. */
export function withdrawParams(accountId: string, asset: AssetKey, amount: string, dest?: { chain: string; to: string }) {
  return { chain: dest?.chain ?? chainOfAsset(ASSETS[asset].id), to: dest?.to ?? accountId, token: ASSETS[asset].id, amount };
}

export function fundParams(asset: AssetKey, amount: string) {
  return { chain: "near" as const, token: ASSETS[asset].symbol, amount };
}
