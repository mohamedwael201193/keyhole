# Frontend requirements (global, production)

The web app must work for any NEAR user worldwide. These come from the worker/contract design and must be met by the site build.

## Wallets
- Use the NEAR wallet selector. A NEAR wallet must support `signMessage` (NEP-413). MetaMask signs the same intent with EIP-191. If the chosen NEAR wallet cannot sign messages, say so and point the user at one that can, or at MetaMask.
- Sign: `message = JSON.stringify({op, account_id, ts_ms: Date.now(), params})`, `recipient = "keyhole"`, `nonce = 32 random bytes` (crypto.getRandomValues). Fresh nonce on every request; never reuse.
- Named and implicit (64-hex) accounts must both display well (truncate the middle of hex ids).

## Calls
- The browser never holds the OutLayer payment key. Requests go through a server route (Vercel function) that adds `X-Payment-Key` and forwards `{op, auth}` to the worker.
- Server route: per-IP rate limit, body size limit (≤ 8 KB), allow only ops `info|status|quote|mint`, no logging of request bodies or amounts.
- Show the attestation link (`/attestations/by-call/<call_id>`) on every result, and the build hash.

## Errors
- Map every worker `error.code` to a short human message plus a fix (e.g. `expired` → "Your clock may be off; sign again"; `over_cap_per_tx` → show the cap and the tier upgrade path; `rate_limited` → countdown).
- Never show raw upstream text as the primary message.

## Copy
- The site is English only. Strings live in `web/messages/en.json`. There is no language switcher and no RTL layout.
- `/ar` and `/ar/...` redirect to the English path. English pages stay at `/`, `/vault`, `/mint`, and the rest, with no `/en` prefix.
- Numbers and USD amounts use English formatting. Times show in the viewer's local zone, and the daily cap resets at UTC midnight.

## Mobile and access
- Mobile-first, works at 360 px width, touch targets ≥ 44 px.
- Mobile wallets connect from the same selector.
- WCAG 2.2 AA: contrast, keyboard navigation, focus rings, `prefers-reduced-motion` turns off heavy animation.
- Fast: LCP < 2.5 s on 4G, lazy-load 3D/motion, static pages where possible.

## Onboarding
- Three steps only: Connect, Mint key (one signature), Open account.
- No sign-up, no email, no KYC fields, no region checks.
- Explain gas-free signing in one line. Show the limits table for each tier before the first action.

## Gaps to close (not built yet)
- Per-holder confidential balances. The worker today quotes into the holder's own addresses (non-custodial). Holder-owned TEE accounts (one OutLayer wallet per holder) are a later step.
- Tier upgrades (Silver/Gold) and paid mint flow.
- OutLayer Policy Engine on the shared wallet as a second layer of caps.
- Public status page for 1Click/OutLayer availability.
