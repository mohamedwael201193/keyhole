#!/usr/bin/env bash
# verify.sh <call_id> [--rebuild]
# Checks a KEYHOLE TEE call: attestation (TDX quote, wasm hash) == FastFS bytes [== your own rebuild].
set -euo pipefail
CALL="${1:?usage: ./verify.sh <call_id> [--rebuild]}"
API="${OUTLAYER_API:-https://api.outlayer.ai}"
need(){ command -v "$1" >/dev/null || { echo "missing $1"; exit 2; }; }
need curl; need jq; need sha256sum
A=$(curl -fsS "$API/attestations/by-call/$CALL")
H=$(jq -r '.executed_wasm_sha256' <<<"$A"); R=$(jq -r '.wasm_hash' <<<"$A"); P=$(jq -r '.project_id' <<<"$A")
M=$(jq -r '.worker_measurement // empty' <<<"$A")
Q=$(jq -r '.tdx_quote | length' <<<"$A")
echo "call         $CALL"; echo "project      $P"; echo "executed     $H"
echo "measurement  ${M:-none}"
DEP="$(dirname "$0")/tee/worker/DEPLOYED_SHA256"
if [ -f "$DEP" ]; then echo "deployed     $(tr -d '[:space:]' < "$DEP")"; fi
fail=0; ok(){ echo "OK   $1"; }; bad(){ echo "FAIL $1"; fail=1; }
[ "$Q" -gt 100 ] && ok "TDX quote present ($Q chars)" || bad "no TDX quote"
[ "$H" = "$R" ] && ok "registered wasm_hash == executed" || bad "wasm_hash $R != executed $H"
PUB=$(tr -d '[:space:]' < "$(dirname "$0")/tee/worker/DEPLOYED_SHA256")
PREV=$(jq -r '[.worker.previous_wasm_sha256] + (.worker.historical_wasm_sha256 // []) | join(" ")' "$(dirname "$0")/identity.json")
if [ "$H" = "$PUB" ]; then ok "executed == published build ${PUB:0:8}"
elif [[ " $PREV " == *" $H "* ]]; then ok "executed == previous build ${H:0:8}, superseded by ${PUB:0:8}"
else bad "executed $H != published build $PUB"; fi
URL="${FASTFS_BASE:-https://main.fastfs.io}/${P%%/*}/outlayer.near/$H.wasm"
F=$(curl -fsS --retry 5 --retry-all-errors --retry-delay 3 "$URL" | sha256sum | cut -d' ' -f1)
[ "$F" = "$H" ] && ok "FastFS $URL sha256 matches" || bad "FastFS sha256 $F"
if [ "${2:-}" = "--rebuild" ]; then
  B=$("$(dirname "$0")/tee/worker/build.sh")
  [ "$B" = "$H" ] && ok "local reproducible build matches executed wasm ($B)" || bad "local build $B differs from executed $H. --rebuild compiles this checkout; it matches a historical attestation only on the commit that published that wasm."
  echo "note  worker_measurement is the TDX RTMR3 measurement of the OutLayer worker image. It is not the wasm sha256."
fi
exit $fail
